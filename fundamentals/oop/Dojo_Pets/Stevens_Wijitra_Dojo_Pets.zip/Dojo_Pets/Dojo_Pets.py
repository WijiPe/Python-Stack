from Dojo_Ninja import Ninja

class Pet:
    def __init__(self, name , type , tricks, health, energy):
        self.name = name
        self.type = type
        self.tricks = tricks
        self.health = health
        self.energy = energy
    def sleep(self):
        self.energy += 25
    def eat(self):
        self.energy += 5
        self.health += 10
    def play(self):
        self.energy += 5
        self.health += 10 
    def noise(self):
        print("meawwwwww")

class Bad(Pet):
    def __init__(self, name, type, tricks, health, energy):
        super().__init__(name, type, tricks, health, energy)
        self.behavior = "stubborn"
    def pet_lazyPet(self):
        super().sleep()
        print("lazy pet")


N1 = Ninja("Jojo", "Lala", "catnip biskit", "salmon", Bad("Noodle", "cat", {"scratch","run"},100,100))

N1.feed()
N1.walk()
N1.bathe()

print(N1.pet.name)

N1.pet.pet_lazyPet()
